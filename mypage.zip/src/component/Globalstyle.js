import React from 'react'


const Globalstyle =
createGlobalstyle`
    *{margin: 0}


`



export default Globalstyle
