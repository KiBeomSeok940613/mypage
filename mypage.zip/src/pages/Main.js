import React from 'react'
import { BrowserRouter } from 'react-router-dom'
import { styled } from 'styled-components'
import "./../index.css"
import mainPic from './../img/picture.png'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {faTwitter} from '@fortawesome/free-solid-svg-icons'

function Main() {
  return (
    <>
    
      <MainBox>
        <img className="Pic"src={mainPic} alt='main'/>
        
          <h3>SEBASTIAN KOLB</h3>
          <TextFlex>
          <p>pixel and magic</p>
          <p>@mypage interection</p>
          
        </TextFlex>
      </MainBox>
     
    
    
      
    </>
  )
}


const MainBox = styled.div`
width: 300px;
height: 500px;
background-color: #fff;
border-radius: 30px;
margin: 200px auto;


img{
  width: 200px; height: 200px; border-radius: 50%; }
h3{display: flex; justify-content: center;}

`
const TextFlex = styled.div`
  flex-direction: column;
  display: flex;
  justify-content: flex-end;
  align-items: center;
  color: #e7e7e7;
  

`


export default Main