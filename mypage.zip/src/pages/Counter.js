import React from 'react'





function Counter() {
  return (
    <div>
        <h1>1</h1>
        <button>-1</button>
        <button>+1</button>
    </div>
  )
}

export default Counter